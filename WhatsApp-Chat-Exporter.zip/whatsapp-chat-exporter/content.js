/* WhatsApp Chat Exporter v4.0 - original-byte media extractor. */
(() => {
  if (window.__WCE_V2_INSTALLED__) return;
  window.__WCE_V2_INSTALLED__ = true;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = (s, fallback='file') => (String(s || '').replace(/[\\/:*?"<>|\x00-\x1F]+/g,'_').replace(/\s+/g,' ').trim().slice(0,140) || fallback);
  const text = el => (el?.innerText || el?.textContent || '').replace(/\u200e/g,'').trim();

  function chatHeader() {
    const main = document.querySelector('#main');
    if (!main) return null;
    const header = main.querySelector('header');
    const title = header?.querySelector('[title]')?.getAttribute('title');
    return title || text(header?.querySelector('span')) || text(header) || 'WhatsApp Chat';
  }

  function parsePre(el) {
    const raw = el.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text') || '';
    // Common form: [12:34, 7/10/2026] Sender: ; also supports [12:34] Sender:
    const m = raw.match(/^\[([^\]]+)\]\s*(.*?):\s*$/);
    return { raw, timestamp: m?.[1] || raw.replace(/^\[|\]$/g,''), sender: m?.[2]?.trim() || '' };
  }

  function messageNodes() {
    const root = document.querySelector('#main');
    if (!root) return [];
    const selectors = [
      '[data-testid="msg-container"][data-id]',
      '[data-testid="message"][data-id]',
      '[role="row"][data-id]',
      '[data-id]'
    ];
    const out = new Map();
    for (const sel of selectors) {
      for (const el of root.querySelectorAll(sel)) {
        const id = el.getAttribute('data-id');
        if (!id || out.has(id)) continue;
        if (!el.querySelector('[data-pre-plain-text]') && !el.querySelector('.selectable-text,[data-testid="msg-text"],[data-testid="image-thumb"],video,audio,[data-testid*="document"],[data-testid*="sticker"]')) continue;
        out.set(id, el);
      }
    }
    return [...out.values()];
  }

  function direction(el) {
    if (el.classList.contains('message-out') || el.querySelector('.message-out')) return 'outgoing';
    if (el.classList.contains('message-in') || el.querySelector('.message-in')) return 'incoming';
    return 'unknown';
  }

  function statusInfo(el) {
    const labels = [...el.querySelectorAll('[aria-label],[title]')].map(x => x.getAttribute('aria-label') || x.getAttribute('title')).filter(Boolean);
    const useful = labels.filter(x => /read|sent|delivered|pending|played|forwarded|edited|starred|reaction/i.test(x));
    return [...new Set(useful)].slice(0,20);
  }

  function unique(arr) { return [...new Set(arr.filter(Boolean))]; }

  function largestSrcset(srcset) {
    if (!srcset) return '';
    return srcset.split(',').map(x => {
      const p = x.trim().split(/\s+/); const w = Number((p[1]||'').replace(/w$/,'')) || 0; return {url:p[0],w};
    }).sort((a,b)=>b.w-a.w)[0]?.url || '';
  }

  function mediaCandidates(el) {
    const result = [];
    const add = (type, url, extra={}) => {
      if (!url || url === 'about:blank' || url.startsWith('data:image/svg')) return;
      result.push({type,url,...extra});
    };
    const mediaZones = [
      ...el.querySelectorAll('[data-testid="image-thumb"], [data-testid="media-container"], [data-testid="sticker-container"], .media-container, .image-thumb-body, [class*="message-image"], [class*="media"]')
    ];
    const scope = mediaZones.length ? mediaZones : [el];

    for (const zone of scope) {
      for (const img of zone.querySelectorAll('img')) {
        if (img.closest('[data-testid*="quoted" i],[aria-label*="quoted" i],[class*="quoted" i],[data-testid*="reaction" i],[class*="reaction" i],[data-testid*="avatar" i],[class*="avatar" i],[data-testid*="contact" i],[class*="contact-card" i]')) continue;
        const avatarLike = !!img.closest('[data-testid*="avatar" i], [aria-label*="profile" i], [class*="avatar" i]');
        const markedMedia = !!img.closest('[data-testid="image-thumb"], [data-testid="sticker-container"], [class*="message-image" i], [class*="image-thumb" i]');
        const largeEnough = (img.naturalWidth || img.width || 0) >= 80 || (img.naturalHeight || img.height || 0) >= 80;
        if (avatarLike || (!markedMedia && !largeEnough)) continue;
        // Prefer the browser's actually selected source. Do NOT automatically add every srcset
        // candidate: WhatsApp frequently uses srcset thumbnails, which caused incorrect exports.
        const selected = img.currentSrc || img.src || img.getAttribute('data-src') || '';
        const srcsetFallback = selected ? '' : largestSrcset(img.getAttribute('srcset'));
        const url = selected || srcsetFallback;
        if (!url) continue;
        const isSticker = !!img.closest('[data-testid="sticker-container"]');
        const intrinsicW = img.naturalWidth || 0, intrinsicH = img.naturalHeight || 0;
        add(isSticker ? 'sticker' : 'image', url, {alt: img.alt || '', width: intrinsicW, height: intrinsicH, sourceKind: img.currentSrc ? 'currentSrc' : (img.src ? 'src' : 'fallback')});
        // If WhatsApp has a download/original blob attached to the image, prefer that as a separate
        // original candidate. It is often the full-resolution object while the <img> is only a preview.
        const link = img.closest('a[href]');
        const href = link?.href || link?.getAttribute('href') || '';
        if (/^(blob:|https?:)/i.test(href) && href !== url && /download|media|image|original/i.test((link?.getAttribute('download')||'') + ' ' + href)) {
          add(isSticker ? 'sticker' : 'image', href, {alt: img.alt || '', sourceKind: 'linked-original'});
        }
      }
      for (const v of zone.querySelectorAll('video')) {
        add('video', v.currentSrc || v.src || v.querySelector('source')?.src, {poster:v.poster || ''});
      }
      for (const a of zone.querySelectorAll('audio')) add('audio', a.currentSrc || a.src || a.querySelector('source')?.src);
      for (const s of zone.querySelectorAll('source[src]')) {
        const parent = s.closest('video,audio'); if (parent) add(parent.tagName.toLowerCase(), s.src);
      }
    }

    // Documents and other attachments frequently expose a blob/data href on an anchor.
    for (const a of el.querySelectorAll('a[href]')) {
      const href = a.href || a.getAttribute('href');
      const label = text(a) || a.getAttribute('aria-label') || '';
      if (!href) continue;
      if (/^(blob:|data:)/.test(href) && (/download|document|file|pdf|doc|xls|ppt|zip|attachment/i.test(label) || a.hasAttribute('download'))) {
        add('document', href, {label, filename:a.getAttribute('download') || label});
      }
    }

    // Some builds expose the image through CSS background-image rather than an <img>.
    for (const zone of mediaZones) {
      for (const node of [zone, ...zone.querySelectorAll('*')]) {
        const bg = getComputedStyle(node).backgroundImage || '';
        const m = bg.match(/url\(["']?(.*?)["']?\)/);
        if (m?.[1]) add('image', m[1].replace(/\\(["'])/g,'$1'));
      }
    }

    const seen = new Set();
    let out = result.filter(x => { const k = `${x.type}|${x.url}`; if (seen.has(k)) return false; seen.add(k); return true; });
    const imgs = out.filter(x => x.type === 'image' || x.type === 'sticker');
    const rest = out.filter(x => x.type !== 'image' && x.type !== 'sticker');
    const chosen = [];
    for (const type of ['image','sticker']) {
      const group = imgs.filter(x => x.type === type);
      if (!group.length) continue;
      const originals = group.filter(x => x.sourceKind === 'linked-original' || x.url.startsWith('blob:'));
      const pool = originals.length ? originals : group;
      pool.sort((a,b) => ((b.sourceKind === 'linked-original')-(a.sourceKind === 'linked-original')) || ((b.width||0)*(b.height||0)-(a.width||0)*(a.height||0)));
      for (const item of pool) {
        const duplicatePreview = chosen.some(x => x.type === type && (x.url === item.url || ((item.width||0) < 600 && (x.width||0) >= 600)));
        if (!duplicatePreview) chosen.push(item);
      }
    }
    return [...rest, ...chosen];
  }

  function parseMessage(el, index) {
    const pre = parsePre(el);
    const id = el.getAttribute('data-id') || '';
    const body = text(el.querySelector('[data-testid="msg-text"], span.selectable-text, .selectable-text, .copyable-text'));
    const quoted = text(el.querySelector('[data-testid="quoted-msg-text"], [data-testid*="quoted"], .quoted-mention'));
    const links = unique([...el.querySelectorAll('a[href]')].map(a => a.href).filter(h => /^https?:/i.test(h)));
    const reactions = unique([...el.querySelectorAll('[aria-label*="reaction" i],[data-testid*="reaction" i]')].map(x => x.getAttribute('aria-label') || text(x)));
    const media = mediaCandidates(el);
    const hasDeleted = /this message was deleted|you deleted this message|message deleted/i.test(text(el));
    const forwarded = /forwarded/i.test(statusInfo(el).join(' ')) || !!el.querySelector('[data-testid*="forwarded"]');
    return {
      id, index, timestamp: pre.timestamp, sender: pre.sender, direction: direction(el), text: body,
      quotedText: quoted, links, reactions, forwarded, deleted: hasDeleted,
      statusLabels: statusInfo(el), media, rawPrePlainText: pre.raw
    };
  }

  function findScroller() {
    const root = document.querySelector('#main');
    if (!root) return null;
    const preferred = [...root.querySelectorAll('[data-testid="conversation-panel-messages"], [class*="conversation-panel-messages"]')];
    for (const x of preferred) if (x.scrollHeight > x.clientHeight + 100) return x;
    const candidates = [...root.querySelectorAll('div')].filter(x => x.scrollHeight > x.clientHeight + 250 && getComputedStyle(x).overflowY.match(/auto|scroll/));
    candidates.sort((a,b)=>(b.scrollHeight-b.clientHeight)-(a.scrollHeight-a.clientHeight));
    return candidates[0] || null;
  }

  function scanMessages(store, mediaQueue) {
    const nodes = messageNodes();
    for (const el of nodes) {
      const id = el.getAttribute('data-id');
      if (!id) continue;
      const m = parseMessage(el, store.size + 1);
      if (!store.has(id)) store.set(id, m);
      else {
        const old = store.get(id);
        // Merge information that may appear only after media/text lazy-loading.
        old.text ||= m.text; old.quotedText ||= m.quotedText; old.sender ||= m.sender; old.timestamp ||= m.timestamp;
        old.links = unique([...old.links,...m.links]); old.reactions = unique([...old.reactions,...m.reactions]);
        old.statusLabels = unique([...old.statusLabels,...m.statusLabels]);
        const mm = new Map(old.media.map(x=>[`${x.type}|${x.url}`,x]));
        for (const x of m.media) mm.set(`${x.type}|${x.url}`, {...mm.get(`${x.type}|${x.url}`), ...x});
        old.media = [...mm.values()];
      }
      for (const item of m.media) mediaQueue.push({messageId:id, item});
    }
  }

  function imageMeta(bytes, mime='') {
    const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const u16=(i,l=false)=>l?(b[i]|(b[i+1]<<8)):(b[i]<<8|b[i+1]);
    const u32=(i,l=false)=>l?((b[i]|(b[i+1]<<8)|(b[i+2]<<16)|(b[i+3]<<24))>>>0):(((b[i]<<24)|(b[i+1]<<16)|(b[i+2]<<8)|b[i+3])>>>0);
    try {
      if (b.length>=24 && u32(0)===0x89504e47 && u32(4)===0x0d0a1a0a) return {width:u32(16),height:u32(20),format:'PNG'};
      if (b.length>=10 && b[0]===0x47&&b[1]===0x49&&b[2]===0x46) return {width:u16(6,true),height:u16(8,true),format:'GIF'};
      if (b.length>=12 && b[0]===0x52&&b[1]===0x49&&b[2]===0x46&&b[3]===0x46&&b[8]===0x57&&b[9]===0x45&&b[10]===0x42&&b[11]===0x50) {
        if (b[12]===0x56&&b[13]===0x50&&b[14]===0x38&&b[15]===0x20) return {width:1+(b[26]|(b[27]<<8)|(b[28]<<16)),height:1+(b[29]|(b[30]<<8)|(b[31]<<16)),format:'WEBP'};
        if (b[12]===0x56&&b[13]===0x50&&b[14]===0x38&&b[15]===0x58) return {width:1+(b[24]|(b[25]<<8)|(b[26]<<16)),height:1+(b[27]|(b[28]<<8)|(b[29]<<16)),format:'WEBP'};
        if (b[12]===0x56&&b[13]===0x50&&b[14]===0x38&&b[15]===0x4c) return {width:1+(b[21]|(b[22]<<8)|(b[23]<<16)),height:1+(b[24]|(b[25]<<8)|(b[26]<<16)),format:'WEBP'};
      }
      if (b[0]===0xff&&b[1]===0xd8) {
        let i=2, orientation=1;
        while(i+9<b.length){ if(b[i]!==0xff){i++;continue;} const marker=b[i+1]; if(marker===0xd9||marker===0xda) break; const len=u16(i+2); if(marker===0xe1 && b[i+4]===0x45&&b[i+5]===0x78&&b[i+6]===0x69&&b[i+7]===0x66){
          const t=i+10, le=b[t]===0x49&&b[t+1]===0x49, ifd=t+8, count=u16(ifd,le); for(let n=0;n<count;n++){const p=ifd+2+n*12, tag=u16(p,le); if(tag===0x0112){orientation=u16(p+8,le);break;}}
        } if(marker>=0xc0&&marker<=0xc3||marker>=0xc5&&marker<=0xc7||marker>=0xc9&&marker<=0xcb||marker>=0xcd&&marker<=0xcf){return {width:u16(i+7),height:u16(i+5),format:'JPEG',orientation,displayWidth:(orientation>=5&&orientation<=8)?u16(i+5):u16(i+7),displayHeight:(orientation>=5&&orientation<=8)?u16(i+7):u16(i+5)};} i+=2+len; }
      }
    } catch {}
    return null;
  }

  async function exactMediaMeta(blob) {
    const type=(blob.type||'').toLowerCase();
    if(!type.startsWith('image/')) return {};
    const max=8*1024*1024;
    const slice=blob.size<=max?blob:blob.slice(0,max);
    const meta=imageMeta(new Uint8Array(await slice.arrayBuffer()),type);
    if(!meta) return {};
    return {pixelWidth:meta.width||0,pixelHeight:meta.height||0,displayWidth:meta.displayWidth||meta.width||0,displayHeight:meta.displayHeight||meta.height||0,imageFormat:meta.format||type,orientation:meta.orientation||1};
  }

  async function sha256(blob) {
    try { const b = await blob.arrayBuffer(); const h = await crypto.subtle.digest('SHA-256', b); return [...new Uint8Array(h)].map(x=>x.toString(16).padStart(2,'0')).join(''); }
    catch { return ''; }
  }

  function extension(mime, url, kind, filename='') {
    const byMime = {'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','video/mp4':'mp4','video/webm':'webm','audio/ogg':'ogg','audio/mpeg':'mp3','audio/mp4':'m4a','application/pdf':'pdf','application/msword':'doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document':'docx','application/vnd.ms-excel':'xls','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'xlsx'};
    if (byMime[mime]) return byMime[mime];
    const f = filename.match(/\.([a-z0-9]{2,8})$/i)?.[1]; if (f) return f.toLowerCase();
    const u = decodeURIComponent((url||'').split('?')[0]).match(/\.([a-z0-9]{2,8})$/i)?.[1]; if (u) return u.toLowerCase();
    return kind === 'sticker' ? 'webp' : ({image:'bin',video:'bin',audio:'bin',document:'bin'}[kind] || 'bin');
  }

  async function fetchBlob(url, timeoutMs=30000) {
    const ctl = new AbortController(); const timer = setTimeout(()=>ctl.abort(),timeoutMs);
    try {
      const r = await fetch(url,{credentials:'include',cache:'force-cache',signal:ctl.signal});
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const blob = await r.blob();
      if (!blob.size) throw new Error('Empty media response');
      return blob;
    } finally { clearTimeout(timer); }
  }

  async function downloadMedia(queue, messages, enabled) {
    const files=[]; const seenSources=new Map(); let failed=0;
    if (!enabled) return {files,found:0,fetched:0,failed:0};
    const maxPerFile=250*1024*1024; const maxTotal=1500*1024*1024; let total=0;
    // De-dupe exact URL first. Same media may be rendered as <img> and CSS background.
    const uniqueQueue=[];
    for (const q of queue) { const key=`${q.item.type}|${q.item.url}`; if (!seenSources.has(key)) { seenSources.set(key,q); uniqueQueue.push(q); } }
    const found=uniqueQueue.length;
    const worker = async () => {
      while (uniqueQueue.length) {
        const q=uniqueQueue.shift(); if (!q) return;
        const msg=messages.get(q.messageId); if (!msg) continue;
        const baseRef={...q.item,source:q.item.url};
        try {
          const blob=await fetchBlob(q.item.url);
          if (blob.size>maxPerFile) throw new Error(`File exceeds ${Math.round(maxPerFile/1024/1024)} MB limit`);
          if (total+blob.size>maxTotal) throw new Error('Export media size limit reached');
          total+=blob.size;
          const hash=await sha256(blob);
          const exact=await exactMediaMeta(blob);
          const ext=extension(blob.type,q.item.url,q.item.type,q.item.filename||q.item.label||'');
          const base=`media/${q.item.type}/message-${clean(q.messageId,'unknown').slice(0,45)}-${String(files.length+1).padStart(5,'0')}`;
          const name=`${base}.${ext}`;
          files.push({name,blob});
          baseRef.exportedPath=name; baseRef.mime=blob.type||''; baseRef.size=blob.size; baseRef.sha256=hash; Object.assign(baseRef,exact); baseRef.bytePreserved=true;
        } catch (e) { baseRef.error=e?.name==='AbortError'?'Timed out':(e?.message||String(e)); failed++; }
        msg.media = msg.media.map(x => x.url===q.item.url && x.type===q.item.type ? {...x,...baseRef} : x);
      }
    };
    await Promise.all([worker(),worker(),worker()]);
    return {files,found,fetched:files.length,failed};
  }

  function u16(n){return new Uint8Array([n&255,(n>>>8)&255]);}
  function u32(n){return new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);}
  function cat(...a){const n=a.reduce((s,x)=>s+x.length,0),o=new Uint8Array(n);let p=0;for(const x of a){o.set(x,p);p+=x.length;}return o;}
  function crc32(buf){let c=0xffffffff;for(let i=0;i<buf.length;i++){c^=buf[i];for(let k=0;k<8;k++)c=(c>>>1)^(0xedb88320&-(c&1));}return (c^0xffffffff)>>>0;}
  const enc=s=>new TextEncoder().encode(s);
  async function makeZip(entries){
    const local=[],central=[];let offset=0;
    for(const e of entries){
      const name=enc(e.name),data=new Uint8Array(await e.data.arrayBuffer()),crc=crc32(data);
      const lh=cat(u32(0x04034b50),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),name,data);
      local.push(lh);
      central.push(cat(u32(0x02014b50),u16(20),u16(20),u16(0),u16(0),u16(0),u16(0),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name));
      offset+=lh.length;
    }
    const l=cat(...local),c=cat(...central),end=cat(u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(c.length),u32(l.length),u16(0));
    return new Blob([l,c,end],{type:'application/zip'});
  }

  function csv(messages){
    const q=v=>`"${String(v??'').replace(/"/g,'""').replace(/\r?\n/g,' ')}"`;
    const head=['index','id','timestamp','sender','direction','text','quotedText','forwarded','deleted','reactions','mediaPaths','mediaErrors','links'].join(',');
    const rows=messages.map((m,i)=>[i+1,m.id,m.timestamp,m.sender,m.direction,m.text,m.quotedText,m.forwarded,m.deleted,m.reactions.join(' | '),m.media.map(x=>x.exportedPath||'').filter(Boolean).join(' | '),m.media.map(x=>x.error||'').filter(Boolean).join(' | '),m.links.join(' | ')].map(q).join(','));
    return [head,...rows].join('\n');
  }

  function textExport(title,messages){
    return [`Chat: ${title}`,`Messages: ${messages.length}`,`Exported: ${new Date().toISOString()}`,'','='.repeat(70),'',...messages.map((m,i)=>`[${i+1}] ${m.timestamp || ''} | ${m.sender || 'Unknown'} | ${m.direction}\n${m.text || (m.media.length ? `[${m.media.map(x=>x.type).join(', ')}]` : '')}${m.quotedText ? `\n> ${m.quotedText}` : ''}${m.links.length ? `\nLinks: ${m.links.join(' ')}` : ''}\n`)].join('\n');
  }

  function readme(title,stats,opts){return `WhatsApp Chat Exporter v4.0\n===========================\n\nChat: ${title}\nExported: ${new Date().toISOString()}\nMessages exported: ${stats.messages}\nMedia references found: ${stats.mediaFound}\nMedia files downloaded: ${stats.mediaFetched}\nMedia files unavailable: ${stats.mediaFailed}\nAuto-loaded history: ${opts.loadHistory ? 'yes' : 'no'}\n\nFILES\n-----\nchat.json       Structured messages, IDs, timestamps, sender, direction, links, reactions and media status.\nchat.csv        Flat table suitable for Excel/Power BI/data analysis.\nchat.txt        Human-readable transcript.\nmedia/          Successfully fetched media grouped by type.\nmedia-index.csv Media inventory with source, size, hash and export status.\nexport-summary.json Export statistics and settings.\nREADME.txt      This file.\n\nMEDIA ACCURACY\n--------------\nThe exporter deliberately prefers WhatsApp's rendered media sources (including data-testid="image-thumb", blob URLs, srcset and media containers) and fetches them inside the WhatsApp Web page context. This is substantially more reliable than trying to fetch blob URLs from an external server.\n\nHowever, WhatsApp Web can render a thumbnail instead of the original file, lazy-load media, or expose a temporary URL. If WhatsApp does not expose the original bytes to the browser page, the ZIP cannot legally or technically reconstruct the original file. The affected message remains in chat.json with an error/status.\n\nHISTORY\n-------\nWhatsApp Web uses a virtualized message list. When automatic history loading is enabled, the extension scrolls upward, scans each batch and remembers messages/media before the page virtualizes them away. Very large chats can take time and may be limited by WhatsApp Web itself.\n\nLIMITATIONS\n-----------\n- DOM-based only; no WhatsApp private database, encryption keys, private APIs, or credentials are accessed.\n- WhatsApp Web's DOM/selectors are unofficial and can change without notice.\n- View-once, disappearing, expired, protected or not-yet-loaded media may be unavailable.\n- Reactions, edited/deleted indicators, stickers, documents and rich message types depend on what the current page exposes.\n- This exporter does not bypass access controls or retrieve media that the browser itself cannot access.\n- ZIP creation is local and uncompressed; very large exports require sufficient browser memory.\n- Exported chats can contain sensitive personal information. Store/share the ZIP responsibly.\n\nUSAGE\n-----\n1. Open web.whatsapp.com and open the target chat.\n2. Load/review the chat if needed.\n3. Open this extension and choose whether to auto-load older history.\n4. Click Export current chat.\n5. The ZIP contains the transcript and successfully accessible media.\n`}

  function mediaCsv(rows){
    const q=v=>`\"${String(v??'').replace(/\"/g,'\"\"').replace(/\r?\n/g,' ')}\"`;
    const head=['index','messageId','timestamp','sender','type','source','exportedPath','mime','size','sha256','error'].join(',');
    return [head,...rows.map((x,i)=>[i+1,x.messageId,x.timestamp,x.sender,x.type,x.source,x.exportedPath,x.mime,x.size,x.sha256,x.error].map(q).join(','))].join('\n');
  }

  async function exportChat(options={}) {
    const title=chatHeader(); if(!title) throw new Error('No open WhatsApp chat detected.');
    const maxMessages=Math.max(100,Math.min(20000,Number(options.maxMessages)||5000));
    const store=new Map(); const mediaQueue=[];
    scanMessages(store,mediaQueue);
    const scroller=options.loadHistory ? findScroller() : null;
    let rounds=0,stable=0,lastCount=store.size;
    if(options.loadHistory && scroller){
      // Move toward oldest messages while collecting each virtualized batch.
      while(rounds<80 && store.size<maxMessages){
        scroller.scrollTop=0; await sleep(650); scanMessages(store,mediaQueue);
        rounds++;
        if(store.size===lastCount) stable++; else stable=0;
        lastCount=store.size;
        if(stable>=4 || scroller.scrollTop<=2 && rounds>8 && store.size===lastCount) break;
      }
      // Return the user to the newest messages after scanning.
      scroller.scrollTop=scroller.scrollHeight; await sleep(400); scanMessages(store,mediaQueue);
    }
    const messages=[...store.values()].slice(0,maxMessages);
    messages.forEach((m,i)=>m.index=i+1);
    const mediaResult=await downloadMedia(mediaQueue,store,options.downloadMedia!==false);
    const exportedMessages=messages;
    const mediaIndex=[];
    for(const m of exportedMessages) for(const x of m.media) mediaIndex.push({messageId:m.id,timestamp:m.timestamp,sender:m.sender,type:x.type,source:x.source||x.url,exportedPath:x.exportedPath||'',mime:x.mime||'',size:x.size||0,pixelWidth:x.pixelWidth||0,pixelHeight:x.pixelHeight||0,displayWidth:x.displayWidth||0,displayHeight:x.displayHeight||0,orientation:x.orientation||1,bytePreserved:x.bytePreserved===true,sha256:x.sha256||'',error:x.error||''});
    const stats={messages:exportedMessages.length,mediaFound:mediaIndex.length,mediaFetched:mediaResult.fetched,mediaFailed:mediaResult.failed,historyRounds:rounds};
    const payload={version:'2.0.0',exportedAt:new Date().toISOString(),chatTitle:title,settings:options,statistics:stats,messages:exportedMessages};
    const summary={version:'2.0.0',chatTitle:title,exportedAt:payload.exportedAt,settings:options,statistics:stats};
    const entries=[
      {name:'chat.json',data:new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})},
      {name:'chat.csv',data:new Blob([csv(exportedMessages)],{type:'text/csv;charset=utf-8'})},
      {name:'chat.txt',data:new Blob([textExport(title,exportedMessages)],{type:'text/plain;charset=utf-8'})},
      {name:'media-index.csv',data:new Blob([mediaCsv(mediaIndex)],{type:'text/csv;charset=utf-8'})},
      {name:'export-summary.json',data:new Blob([JSON.stringify(summary,null,2)],{type:'application/json'})},
      {name:'README.txt',data:new Blob([readme(title,stats,options)],{type:'text/plain;charset=utf-8'})},
      ...mediaResult.files.map(f=>({name:f.name,data:f.blob}))
    ];
    const zip=await makeZip(entries);
    const url=URL.createObjectURL(zip); const a=document.createElement('a'); a.href=url; a.download=`${clean(title,'whatsapp-chat')}-export-${new Date().toISOString().slice(0,10)}.zip`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),60000);
    return {ok:true,...stats};
  }

  chrome.runtime.onMessage.addListener((msg)=>{
    if(msg?.type!=='EXPORT_CHAT') return false;
    exportChat(msg.options||{}).catch(e=>{
      try { chrome.runtime.sendMessage({type:'EXPORT_ERROR', error:e?.message||String(e)}); } catch {}
    });
    return false;
  });
})();
