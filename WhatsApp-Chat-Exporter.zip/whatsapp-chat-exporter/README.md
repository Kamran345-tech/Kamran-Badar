# WhatsApp Chat Exporter v3.0

A local-only Chrome Manifest V3 extension that exports the currently open WhatsApp Web conversation into a ZIP archive.

## Features

- Export the current chat without a backend or external API.
- Automatically load older history by scrolling the virtualized WhatsApp Web message list.
- Sender, timestamp, message ID and incoming/outgoing direction.
- Text, quoted/replied text, links, reactions and useful status labels when exposed by the DOM.
- Detect and download accessible photos, videos, audio/voice media, stickers and documents.
- De-duplicate repeated media sources such as an `<img>` plus CSS background thumbnail.
- Fetch `blob:` media inside the WhatsApp Web page context, where the browser has access to it.
- Record media MIME type, byte size and SHA-256 hash.
- Record failed/inaccessible media in `chat.json` and `media-index.csv` instead of silently dropping it.
- Generate `chat.json`, `chat.csv`, `chat.txt`, `media-index.csv`, `export-summary.json`, `README.txt` and a structured `media/` directory.
- Configurable maximum message count and media download toggle.
- No account credentials, WhatsApp private database, encryption keys or remote service are used.

## Install

1. Extract the ZIP.
2. Open `chrome://extensions/`.
3. Enable **Developer mode**.
4. Choose **Load unpacked**.
5. Select the `whatsapp-chat-exporter` directory.
6. Open or refresh `https://web.whatsapp.com/`.
7. Open the chat you want to export.
8. Click the extension and choose the desired options.

## Why media extraction can still be incomplete

WhatsApp Web's DOM and selectors are not a stable public API. The extension therefore uses several selectors and media discovery methods instead of relying on one CSS class. Current web implementations commonly expose rendered media as `blob:` URLs and image thumbnails; those URLs need to be fetched from the page context rather than from an external server.

The exporter prefers rendered media containers, `data-testid="image-thumb"`, `srcset`, `data-src`, `<video>`, `<audio>`, attachment links and CSS background images. It also filters common avatar/profile images so a contact's profile photo is not accidentally exported as message media.

If WhatsApp only exposes a thumbnail, a media URL has expired, the attachment has not loaded yet, the content is view-once/disappearing/protected, or the browser cannot fetch the bytes, the original file cannot be reconstructed by this extension. The message remains in the structured export with an error/status field.

## History loading

WhatsApp Web virtualizes long conversations, so only part of a large conversation may exist in the DOM at any moment. With **Load older messages automatically** enabled, the extension repeatedly scrolls toward the oldest available messages, scans each rendered batch and retains the results before WhatsApp virtualizes those nodes away. It then returns the chat to the newest position.

For very large chats, use a reasonable message limit and allow the browser time to process the export.

## ZIP output

- `chat.json` — complete structured message records.
- `chat.csv` — flat message table for Excel/Power BI/data analysis.
- `chat.txt` — readable transcript.
- `media-index.csv` — every detected media reference, its exported path, MIME, size, SHA-256 and error status.
- `media/image/` — accessible images.
- `media/video/` — accessible videos.
- `media/audio/` — accessible audio/voice files.
- `media/sticker/` — accessible stickers.
- `media/document/` — accessible document attachments.
- `export-summary.json` — export statistics and settings.
- `README.txt` — limitations and export notes.

## Important limitations

- WhatsApp Web can change its DOM without notice; selectors may require future maintenance.
- Only information and media exposed to the logged-in browser page can be exported.
- View-once, disappearing, expired, protected or not-yet-loaded media may not be accessible.
- Rich message types such as polls, contacts, locations and system events depend on the current DOM and may have partial metadata.
- The ZIP is created locally and uncompressed. Very large exports need substantial browser memory.
- The extension does not bypass WhatsApp access controls or retrieve data from private/internal APIs.
- Exported conversations can contain personal or confidential information. Store and share the ZIP responsibly.

## Troubleshooting

### "Could not establish connection. Receiving end does not exist."

Refresh the extension from `chrome://extensions/`, refresh WhatsApp Web, then reopen the target chat. The popup also attempts to inject the content script automatically when the WhatsApp tab was already open before the extension was loaded.

### Media count is high but some files are missing

Scroll through the relevant portion of the chat and let media thumbnails finish loading, then export again. For very old media, use the automatic history option. Check `media-index.csv` to see exactly which files failed and why.

### Only recent messages appear

Keep **Load older messages automatically** enabled. WhatsApp Web virtualizes long chats, and only rendered batches are available to a DOM-only extension.

## Privacy

No chat content or media is sent to a server by this extension. All extraction, hashing and ZIP creation occur in the browser.

## Disclaimer

This project is an independent utility and is not affiliated with, sponsored by or endorsed by WhatsApp or Meta. Use it only for chats and media you are authorized to export, and comply with applicable privacy, employment and data-protection requirements.


VERSION 3.0 FIXES
-----------------
- Fixed ZIP central-directory header generation that could produce corrupt archives.
- Fixed the asynchronous message-channel warning by making export fire-and-forget from the popup.
- The popup no longer waits for a long media export response, so the popup lifecycle cannot cancel the export.
- If a media URL cannot be fetched, the item is recorded in media-index.csv and chat.json instead of corrupting the archive.


IMAGE ACCURACY UPDATE
---------------------
- Exported images are copied as the original bytes returned by the browser; no canvas resize, recompression, or format conversion is performed.
- The exporter records exact file byte size plus pixel width/height when the image format can be parsed (JPEG, PNG, WebP, GIF).
- JPEG EXIF orientation is recorded and display dimensions are calculated separately so rotated images are not misreported.
- CSS/rendered dimensions are not treated as the original image dimensions.
- srcset thumbnails are no longer blindly exported as additional images. The selected browser source is preferred, with a linked original candidate used when exposed.
- If WhatsApp only exposes a thumbnail/preview, the exporter cannot reconstruct the original; the media index records the actual downloaded dimensions and bytes.
