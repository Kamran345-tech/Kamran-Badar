const btn = document.getElementById('export');
const status = document.getElementById('status');
const history = document.getElementById('history');
const media = document.getElementById('media');
const maxMessages = document.getElementById('maxMessages');
function setStatus(s, cls=''){ status.className = 'status '+cls; status.textContent = s; }
async function getActiveWhatsAppTab(){
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id || !tab?.url?.startsWith('https://web.whatsapp.com/')) throw new Error('Open WhatsApp Web first, then open the extension.');
  return tab;
}
async function ensureContentScript(tab){
  try {
    await chrome.tabs.sendMessage(tab.id,{type:'WCE_PING'});
    return true;
  } catch {
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});
    return true;
  }
}
async function startExport(tab, options){
  await ensureContentScript(tab);
  chrome.tabs.sendMessage(tab.id,{type:'EXPORT_CHAT',options},()=>{ void chrome.runtime.lastError; });
}

btn.addEventListener('click',async()=>{
  btn.disabled=true; setStatus('Connecting…');
  try{
    const tab=await getActiveWhatsAppTab();
    await startExport(tab,{loadHistory:history.checked,downloadMedia:media.checked,maxMessages:Math.max(100,Math.min(20000,Number(maxMessages.value)||5000))});
    setStatus('Export started. Keep WhatsApp Web open until the ZIP download begins.', 'ok');
  }catch(e){setStatus(e?.message||String(e),'err');}
  finally{btn.disabled=false;}
});
